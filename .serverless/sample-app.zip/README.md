https://bitbucket.org/blog/deploy-an-express-js-app-to-aws-lambda-using-the-serverless-framework
https://serverless.com/framework/docs/providers/aws/guide/credentials/
